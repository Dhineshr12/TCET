package TNCT;
import java.util.HashMap;
import java.util.Scanner;

public class testthree {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
       
        System.out.println("Enter a string:");
        String text = scanner.nextLine();
        String normalizedText=text.toLowerCase();
        
        String[] words = normalizedText.split("\\s+");

        
        HashMap<String, Integer> wordCountMap = new HashMap<>();

        
        for (String word : words) {
            wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
        }

        
        System.out.println("Word Frequencies:");
        for (String word : wordCountMap.keySet()) {
            System.out.println(word + ": " + wordCountMap.get(word));
        }

       
        scanner.close();
    }
}