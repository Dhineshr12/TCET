package TNCT;
import java.util.Scanner;
public class testone {
	
	@FunctionalInterface
	interface Sayable {
	    String say(String name);
	}
	public class Main {
	        public static void main(String[] args) {
	       
	        Sayable sayable = (name) -> "Hello, " + name + "! Welcome!";
	        
	        String greeting = sayable.say("Dhinesh");
	        System.out.println(greeting);
	    }
	}

}
