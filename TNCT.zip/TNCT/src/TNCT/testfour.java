package TNCT;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
public class testfour {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
       
        List<Integer> numbers = new ArrayList<>();
        for (String str : input.split("\\s+")) {
            try {
                numbers.add(Integer.parseInt(str));
            } catch (NumberFormatException e) {
                System.out.println("Invalid input: " + str + " is not an integer.");
            }
        }
        
        List<Integer> evenNumbers = numbers.stream().filter(n -> n % 2 == 0).collect(Collectors.toList()); 
        System.out.println(evenNumbers);
        scanner.close();
    }
}