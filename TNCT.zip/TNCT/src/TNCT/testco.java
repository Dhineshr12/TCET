package TNCT;

import java.util.Arrays;
import java.util.Scanner;

public class testco {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int[] crates = new int[n];
        int nonEmptyIndex = 0; 
        for (int i = 0; i < n; i++) {
            crates[i] = scanner.nextInt();
        }
       
        for (int i = 0; i < crates.length; i++) {
            if (crates[i] != 0) {
                crates[nonEmptyIndex] = crates[i];
                nonEmptyIndex++;
            }
        }
        
        for (int i = nonEmptyIndex; i < crates.length; i++) {
            crates[i] = 0;
        }
        System.out.println("Array after moving empty crates: " + Arrays.toString(crates));
        scanner.close();
    }
}